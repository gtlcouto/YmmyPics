//
//  HeaderTableViewCell.m
//  Ymmy Pics
//
//  Created by Gustavo Couto on 2015-02-03.
//  Copyright (c) 2015 Gustavo Couto. All rights reserved.
//

#import "HeaderTableViewCell.h"

@interface HeaderTableViewCell ()




@end
@implementation HeaderTableViewCell
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
